import React from "react"

import WelcomeHeader from "../welcome-header"

const WelcomePage = () => {
    return (
        <div className="jumbotron">
            <WelcomeHeader />
        </div>
    )
}

export default WelcomePage
