import StarshipIntro from "./starship-intro"

export default StarshipIntro
