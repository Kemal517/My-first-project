import WelcomeHeader from "./welcome-header"

export default WelcomeHeader
