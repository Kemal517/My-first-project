import ErrorBoundary from "./error-boundry"

export default ErrorBoundary
